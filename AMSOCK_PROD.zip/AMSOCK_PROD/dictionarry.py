call_types = {
        'grenzen': 'AM_TO_FASTAPI_API',
        'startup': 'AM_TO_FASTAPI_API',
        'close_ASA': 'AM_TO_FASTAPI_API',
        'wall': 'AM_TO_FASTAPI_API',
        'componenent_details': 'AM_TO_FASTAPI_API',
        'student_mes': 'AM_TO_FASTAPI_SOCK',
        'next_exercises': 'AM_TO_FASTAPI_SOCK',
        'report': 'AM_TO_FASTAPI_SOCK',
        'explanation': 'AM_TO_FASTAPI_SOCK',
        'test_result': 'AM_TO_FASTAPI_SOCK',
        'question_yn': 'AM_TO_FASTAPI_SOCK',
        'asa_mes': 'AM_TO_FASTAPI_SOCK',
       }

level_dict = {
        "1": "11",
        "2": "21",
        "3": "101",
        "4": "201",
        "5": "1001",
        "6": "2001"
}
